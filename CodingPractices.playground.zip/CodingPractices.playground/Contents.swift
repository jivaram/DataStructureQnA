import UIKit
import Foundation
//func addInt(a: Int, b: Int) -> Int {
//    return a + b
//}
//func compare(a: Int, b: Int) -> Bool {
//    return true
//}
//
////print(addInt(a: 2, b: 2))
//
//let some = addInt(a: 2, b: 2)
////print(some)
//let result = { (a: Int, b: Int) -> Int in
//    return a + b
//}
//
//print(result(2, 2))
//
//let number = [2,4,1,5,3,6]
//func sortedArrayData(a: Int, b: Int,callBack: @escaping (Bool) -> Void) {
//    callBack(a<b)
//}
//
//let sortArray: () = sortedArrayData(a: 8, b: 4) { isSuccess in
//    print(isSuccess)
//}
//
//func solutions(s: String) -> String {
//    var noOfSpace = s.replacingOccurrences(of: " ", with: "")
//    var noOFDash = noOfSpace.replacingOccurrences(of: "-", with: "")
//   //return noOFDash
//    var result = ""
//    var count = -2
//    for c in noOFDash {
//        result.append(c)
//        if count % 3 == 0 {
//            result.append("-")
//        }
//        count += 1
//    }
//    if result.last == "-" {
//        result = String(result.dropLast())
//    }
//    //return result
//    var char  = Array(result)
//    let secondLastChar = char.count - 2
//    if char[secondLastChar] == "-" {
//        char[secondLastChar] = char[secondLastChar - 1]
//        char[secondLastChar - 1] = "-"
//    }
//    return String(char)
//}
//
//print(solutions(s: "a  dv-ah sdvaacddhga"))


//Protocols are blueprint of methods, properties, and other requirements that suit a particular task or piece of functionality. It’s an interface. A powerful feature of Swift language.
//In its simplest form, a protocol is an interface that describes some properties and methods. Any type that conforms to a protocol should fill in the specific properties defined in the protocol with appropriate values and implement its requisite methods


//protocol PersonDetailsProtocol {
//    func didGetAddress(address: String)
//    var age: Int { get }
//}
//
//extension PersonDetailsProtocol {
//    func didGetAddress(address: String) {}
//    var age: Int { return 0 }
//}
//
//class Detsils : PersonDetailsProtocol {
//    
//    func didGetAddress(address: String) {
//       //print("Kasganj")
//    }
//}
//
//
///// copy and write
/////
//
//struct PersonDetails {
//    var numberOfPersion: Int = 8
//}
//
//class Person {
//    
//    init () {
//        var a1 = [PersonDetails]()
//        var a2 = a1
//        print(address(&a1))
//        print(address(&a2))
//    }
//
//    func address(_ object: UnsafeRawPointer) -> String {
//        let address = Int(bitPattern: object)
//        return NSString(format: "%p", address) as String
//    }
//    
//}
//
////let person = Person()
//
//
//let sum = { (a, b) -> Int in
//    return a + b
//}
//print(sum(4, 4))
//
//let multiply: (Int, Int) -> Int =  {a, b in
//    return a * b
//}
//
//let result = multiply(2, 2)
//
//func operationResult (a: Int, b: Int, opration: (Int, Int) -> Int) -> Int {
//    opration(a, b)
//}
//
//let additionResult = operationResult(a: 4, b: 4) { a, b in
//    return a + b
//}
//print(additionResult)
//
//
//func makeIncrementer(incrementAmount: Int) -> () -> Int {
//    var total = 0
//    let incrementer: () -> Int = {
//        total += incrementAmount
//        return total
//    }
//    return incrementer
//}
//
//let incrementByTwo = makeIncrementer(incrementAmount: 2)
//print(incrementByTwo())
//print(incrementByTwo()) 


//refrence and value type

//struct Person {
//    var a = 5
//}
//
//class Test {
//    var a = 8
//    
//}
//
//
//var person1 = Person()
//print(person1.a)
//var b = person1
//b.a = 9
//print(person1.a, b.a)
//
//var test1 = Test()
//print(test1.a)
//var c = test1
//c.a = 10
//print(test1.a, c.a)


//class CompletionHandler {
//    func count() {
//        for i in 0...50 {
//            if i == 25 {
//                if let url = URL(string: "https://scaler.com") {
//                    URLSession.shared.dataTask(with: url) { (data, response, error) in
//                        print("Received response")
//                    }.resume()
//                }
//            }
//            print("I = ", i)
//        }
//    }
//}
//let newInstance = CompletionHandler()
//newInstance.count()

//let count = 1
//switch count {
//case 1:
//    print("this is 1st satement")
//    fallthrough
//case 2:
//    print("this is 2st satement")
//    fallthrough
//case 3:
//    print("this is 3rd satement")
//case 4:
//    print("")
//case 9:
//    print("this is 9th satement")
//    fallthrough
//case 10:
//    print("this is fallthrough example")
//    
//default:
//    print("this is default satement")
//}

//let twoDArray = [[1,2,3], [4,5,6], [7,8,9]]
//
//for i in 0..<twoDArray.count {
//    for j in 0..<twoDArray.count {
//        print(twoDArray[i][j])
//    }
//}

//func printPattern(n: Int) {
//    
//    for i in 1..<n + 1 {
//        for j in 1..<i+1{
//            print(j, terminator: " ")
//        }
//        print("\n")
//    }
//}
//
//
//func printPyramid(n: Int) {
//    for i in 0..<n {
//            for _ in 0..<(n - i - 1) {
//                print(" ", terminator: "")
//            }
//            for i in 0..<(2 * i + 1) {
//                print("*", terminator: "")
//            }
//            print("")
//        }
//}
////printPyramid(n: 5)
//
//func sorting(arr: inout [Int]) -> [Int]{
//    
//    for i in 0..<arr.count {
//        for j in 0..<arr.count{
//            if arr[j] > arr[i] {
//                var temp = 0
//                temp = arr[i]
//                arr[i] = arr[j]
//                arr[j] = temp
//            }
//        }
//    }
//    return arr
//}
//
//var arra = [82,2,0,40,40,3,1,6,5]
////print(sorting(arr: &arra))
//
//
//func cuncurrency() {
//    print("Start")
//    print("end")
//    print("again Start")
//}
////cuncurrency()
//
//func generateOutput(from dataArray: [Any]) -> String {
//    var output = ""
//    
//    var i = 0
//    while i < dataArray.count {
//        if let str = dataArray[i] as? String {
//            if i + 1 < dataArray.count, let count = dataArray[i + 1] as? Int {
//                output += String(repeating: str, count: count)
//                i += 2 // Move to the next string and count
//                continue
//            }
//        }
//        i += 1 // Move to the next element
//    }
//    
//    return output
//}
//
//let dataArray = ["a", 1, "b", 2, 1, "c", 10, "c", 2] as [Any]
//let output = generateOutput(from: dataArray)
//print(output)


//class CustomThread {
//    func createThread() {
//        let thread: Thread = Thread(target: self, selector: #selector(threadSelector), object: nil)
//        thread.start()
//    }
//
//    @objc func threadSelector() {
//        print("Custom thread in action")
//    }
//}
//
//let customThread = CustomThread()
//customThread.createThread()

//Higher order function practice
// higher order function is a function that takes a functions as arguments parameters and return result as a function here are some higher order function
//basicaly we are use higher order function because with the higher ordr function we can reduce the redundency of the code or we are writing a code woth higher order function in optimize ways and clean code it is complex to understand but easy to understand how we can use these higher order function
/**
 forEach()

 map()

 compactMap()

 flatMap()

 filter()

 reduce()

 sort()

 sorted()
 */

//for each: it will iterate all are element of a collection like array , dictionary and not return anything. remember we can't user continue ans break inside the for each function to exit the currently ecxxecution statements.

//let numbersInWord = ["One", "Two", "Three", "Four", "Five", "Six"]
//numbersInWord.forEach {
//   element in print(element)
//}

/*In the above example, you can see the forEach function iterating over all the elements. When you want an iteration over all the elements without breaking the execution flow, forEach() is best to use.*/

//map: map function perform an operation on all elemnts of a collection and returning a new collection with result of that operation

//struct Person {
//    var name: String
//    var isSubscribed: Bool
//    var email: String?
//}
//
//let person = [Person(name: "Jiva", isSubscribed: true, email: "jiva@nbh.com"),
//              Person(name: "Parsu", isSubscribed: false, email: "parsu@gamil.com"),
//              Person(name: "Reshma", isSubscribed: true, email: nil)
//]

//let personName = person.map({$0.name})
//print(personName)
//let personIsSubscribed = person.map({$0.isSubscribed})
//print(personIsSubscribed)
//let personEmail = person.map({$0.email})
//print(personEmail)
//
////compact map: Iterating through the elements in an array, compactMap() returns an updated array only containing elements that satisfy the condition stated within its body. The array will be updated without any elements that result in a nil value.
////basically compact map return as a result no contails nil value
//
//let personEmailWithCompactMap = person.compactMap({$0.email})
//print(personEmailWithCompactMap)
//let personNameWithCompactMap = person.compactMap({$0.name})
//print(personNameWithCompactMap)


extension Collection {
    func jivaMap<T>(_ transform: (Element) throws -> T) rethrows -> [T] {
        var result:[T] = []
        for item in self {
            result.append(try transform(item))
        }
        return result
    }
}

struct Person {
    var name: String
    var isSubscribed: Bool
    var email: String?
}

let person = [Person(name: "Jiva", isSubscribed: true, email: "jiva@nbh.com"),
              Person(name: "Parsu", isSubscribed: false, email: "parsu@gamil.com"),
              Person(name: "Reshma", isSubscribed: true, email: nil)
]

let myMapName = person.jivaMap({$0.name})
print(myMapName)
let myMapEmail = person.jivaMap({$0.email})
print(myMapEmail)


class A {
    var a = 10
}

struct B {
    var b = 20
}

var aObject = A()
print(aObject.a)
var aa = aObject
print(aa.a)
aa.a = 15
print(aObject.a)
print(aa.a)




